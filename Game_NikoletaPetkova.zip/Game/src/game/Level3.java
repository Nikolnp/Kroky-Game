/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import city.cs.engine.Body;
import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.util.Random;
import javax.swing.ImageIcon;
import org.jbox2d.common.Vec2;

/**
 *
 * @author NIKOLETA
 */
public class Level3 extends GameLevel {
    private static final int NUM_COINS = 5;
    private Image background;

    
     @Override
    public void populate(Game game) {
        super.populate(game);

        // make the ground
        int groundThickness = 2;
        int groundLenght = 30;
     
        Shape groundShape = new BoxShape(groundLenght, groundThickness);
        Body ground = new StaticBody(this, groundShape);
        ground.setPosition(new Vec2(0, 0));
        
        //make the walls
        int wallHight=60;
        
        Shape wallShapeOne = new BoxShape(wallHight + groundThickness , 2.5f);
        Body wallOne = new StaticBody(this,wallShapeOne);
        wallOne.rotateDegrees(90);
        wallOne.setPosition(new Vec2(-32.5f,wallHight));
        
        Shape wallShapeTwo = new BoxShape(wallHight + groundThickness , 2.5f);
        Body wallTwo = new StaticBody(this,wallShapeTwo);
        wallTwo.rotateDegrees(90);
        wallTwo.setPosition(new Vec2(32.5f,wallHight));
        
        
        // make platforms
       Shape boxShape = new BoxShape(5, 0.5f);
       
       
       int yPos = 0;
       int platformNum=wallHight/5;
   
      for (int i = 0; i<platformNum; ++i){
          Random rand = new Random();
          int randX=rand.nextInt(30)-15;
           

            Body platform = new StaticBody(this, boxShape);
            platform.setPosition(new Vec2(randX, yPos+=10));
            platform.setFillColor(Color.green);
            Body coin = new Coin(this);
            coin.setPosition(new Vec2(-10,60));
            coin.addCollisionListener(new PickItUp(getPlayer()));
             
       }
    }
   @Override
    public Vec2 startPosition() {
        return new Vec2(0, 0);
    }

    @Override
    public Vec2 doorPosition() {
        return new Vec2(0,60);
    }

    @Override
    public boolean isCompleted() {
        return getPlayer().getCoinCount() >= NUM_COINS;
    }
    @Override
    public Vec2 enemyStartPosition() {
        return new Vec2(0,50);
    }


}
