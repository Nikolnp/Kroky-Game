
package game;

import city.cs.engine.*;

/**
 *
 * @author NIKOLETA
 */
public class Door extends StaticBody {


    public Door(World world) {
        super(world, new BoxShape(30,2));
        
    }
   
  
    
}
