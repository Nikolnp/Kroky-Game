/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import city.cs.engine.*;

/**
 *
 * @author NIKOLETA
 */
/* creating a subclass of the Walker class to represent Hero1
The hero can collect coins and a message is displayed in the console 
with the amount collected.
*/
public class Hero extends Walker {
    
    private static final Shape shape = new PolygonShape(
           -0.392f,1.018f, 0.288f,1.03f, 1.059f,0.49f, 0.705f,-0.518f, 0.231f,-1.014f, -0.521f,-1.03f, -1.062f,0.423f, -0.414f,0.999f);
 
    private static final BodyImage image =
        new BodyImage("data/cheburashka.png", 2.25f);
   
    public int coinCount;
    public int lifeCount;
    
    public Hero(World world) {
        super(world,shape);
        addImage(image);
    }
    public int getCoinCount() {
        return coinCount;
    }
    public int getLifeCount() {
        return lifeCount;
    }

    public void setLifeCount(int lifeCount) {
        this.lifeCount = lifeCount;
    }

    public void setCoinCount(int coinCount) {
        this.coinCount = coinCount;
    }
  

    public void incrementCoinCount() {
        coinCount++;
        System.out.println("Nice!  Coin count = " + coinCount);
    }
    public void decrementLifeCount() {
        lifeCount--;
        System.out.println("Lifes <3 : " + lifeCount);
    }
    public void incrementLifeCount() {
        lifeCount++;
        System.out.println("Lifes <3 : " + lifeCount);
    }

   

    
    
}
