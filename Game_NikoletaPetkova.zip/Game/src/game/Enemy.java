/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author NIKOLETA
 */
import city.cs.engine.*;


/* creating a subclass of the DynamicBody  class to represent The enemy
The enemy can kill Hero1 which is the banker in the game but gets killed by Hero2 who is the worrier.

*/
public class Enemy extends Walker {

 private static final Shape shape = new PolygonShape(
         -2.576f,1.065f, -1.1f,1.035f, 3.491f,-0.251f, 3.33f,-0.412f,
         0.216f,-1.065f, -1.371f,-0.854f, -3.511f,-0.07f, -2.627f,1.015f);

    private static final BodyImage enemyImage =
        new BodyImage("data/kroko.png", 2.25f);

    
    public Enemy(World world) {
        super(world, shape);
        addImage(enemyImage);
    }
}
