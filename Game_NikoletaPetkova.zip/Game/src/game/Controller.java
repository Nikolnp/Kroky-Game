/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author NIKOLETA
 */
import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/*The class controls Hero1 with the keyBoard


*/
public class Controller extends KeyAdapter {

    private static final float JUMPING_SPEED = 15;
    private static final float WALKING_SPEED = 5;
    private static final float INCREASED_JUMPING_SPEED = 30;

    private Walker body;

    public Controller(Walker body) {
        this.body = body;
    }

    public void update() {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_ESCAPE) { // ESC = quit
            System.exit(0);
            
        } else if (key == KeyEvent.VK_SPACE) { // SPACE = jump
            Vec2 v = body.getLinearVelocity();

            // only jump if body is not already jumping
            if (Math.abs(v.y) < 0.01f) {
                body.jump(JUMPING_SPEED);
            }

        } else if (key == KeyEvent.VK_C) { // SPACE = jump
            Vec2 v = body.getLinearVelocity();

            // only jump if body is not already jumping
            if (Math.abs(v.y) < 0.01f) {
                body.jump(INCREASED_JUMPING_SPEED);
            }

        }
        
        else if (key == KeyEvent.VK_LEFT) {
            body.startWalking(-WALKING_SPEED); // LEFT ARROW = walk left
        } else if (key == KeyEvent.VK_RIGHT) {
            body.startWalking(WALKING_SPEED); // RIGHT ARROW = walk right
        }

    }


       @Override
        public void keyReleased
        (KeyEvent e) {
        int key = e.getKeyCode();
            if (key == KeyEvent.VK_LEFT) {
                body.stopWalking();
            } else if (key == KeyEvent.VK_RIGHT) {
                body.stopWalking();

            } else if (key == KeyEvent.VK_DOWN) {
                body.stopWalking();
            }

        }
         public void setBody(Walker body) {
        this.body = body;
    }
}

    
