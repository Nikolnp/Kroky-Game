/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import city.cs.engine.*;

/**
 *
 * @author NIKOLETA
 * 
 */
// creating a subclass of DynamicBody class to represent Coins which Player1 would collect
public class Coin extends DynamicBody {
    private static final Shape shape = new PolygonShape(
           0.14f,0.262f, 0.262f,0.094f, 0.226f,-0.131f, 0.011f,-0.277f, -0.206f,-0.181f, -0.275f,0.024f, -0.167f,0.271f, 0.127f,0.263f);
    
     private static final BodyImage image =
        new BodyImage("data/coin.gif", 0.85f);
    

 public Coin(World world) {
        super(world, shape);
          addImage(image);
 
    }
 
}
