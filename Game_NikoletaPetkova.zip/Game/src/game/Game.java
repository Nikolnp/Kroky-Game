/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import city.cs.engine.*;
/*Contains all of the classes for creating
user interfaces and for painting graphics and images.*/
import javax.swing.JFrame;

/**
 *
 * @author NIKOLETA
 */
//The main class of the  Multy Player Game
public class Game {

    // The world in which the objects interact with each other
    private GameLevel world;
    //specialised J panel display of the world
    private MyView view;
    // private MyView view2;
    private int level;

    private Controller controller;
    

    // initializing the Game class
    public Game() {
        // make the world
        level = 1;
        world = new Level1();
        world.populate(this);

       
        
        view = new MyView(world, 800, 800);
        //Displays the world in a frame
        final JFrame frame = new JFrame("Multi-Level Kroky Game");
       
     

        // quit the application when the game window is closed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // display the world view in the window frame
        frame.add(view);
        // don't let the game window be resized
        frame.setResizable(false);
        // size the game window frame to fit the world view
        frame.pack();
        // make the window frame visible
        frame.setVisible(true);
        // get keyboard focus
        frame.requestFocus();
        // give keyboard focus to the frame whenever the mouse enters the view
        //  view.addMouseListener(new GiveFocus(frame));

        // debug view
        JFrame debugView = new DebugViewer(world, 500, 500);

        // set a 1 meter grid to help scale the bodies
        //view.setGridResolution(1);
        view.addMouseListener(new Focus(frame));

        // connect the keyboard control to the Players
        controller = new Controller(world.getPlayer());
        
        
        frame.addKeyListener(controller);

        // tracking the Players
        world.addStepListener(new Tracker(view, world.getPlayer()));

        // start!
        world.start();
    }

    /**
     * The player in the current level.
     */
    public Hero getPlayer() {
        return world.getPlayer();
    }

    /**
     * Is the current level of the game finished?
     */
    public boolean isCurrentLevelCompleted() {
        return world.isCompleted();
    }

    /**
     * Advance to the next level of the game.
     */
    public void goNextLevel() {
        world.stop();
        Hero oldHero = world.getPlayer();
        if (level == 1) {
       
            level++;
            // get a new world
            world = new Level2();
            // fill it with bodies
            world.populate(this);
            // switch the keyboard control to the new player
            controller.setBody(world.getPlayer());

            world.addStepListener(new Tracker(view, world.getPlayer()));

            world.getPlayer().setCoinCount(oldHero.getCoinCount());
            // show the new world in the view
            view.setWorld(world);

            view.setBackgroundImage("data/grass.jpg");

            world.start();
        }
        
        else if (level == 2) {
         
            level++;
            // get a new world
            world = new Level3();
            // fill it with bodies
            world.populate(this);
            // switch the keyboard control to the new player
            controller.setBody(world.getPlayer());

            world.addStepListener(new Tracker(view, world.getPlayer()));

            world.getPlayer().setCoinCount(oldHero.getCoinCount());
            // show the new world in the view
            view.setWorld(world);
            view.setBackgroundImage("data/wood.jpg");

            world.start();
           
        }     else if(level==3){
                      System.exit(0);}
    }

    //run the game
    public static void main(String[] args) {
        new Game();
    }

    String getCoinCount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
