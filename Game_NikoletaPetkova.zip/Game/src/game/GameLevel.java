/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import city.cs.engine.World;
import java.awt.Image;
import org.jbox2d.common.Vec2;

/**
 *
 * @author NIKOLETA
 */
public abstract class GameLevel extends World {
    private Enemy enemy;
    private Hero player;
    private MyView view;
    private GameLevel world;

    public Hero getPlayer() {
        return player;
    }

    public void setPlayer(Hero player) {
        this.player = player;
    }

    public Enemy getEnemy() {
        return enemy;
    }

    public void setEnemy(Enemy enemy) {
        this.enemy = enemy;
    }

    public MyView getView() {
        return view;
    }

    public void setView(MyView view) {
        this.view = view;
    }
     public void populate(Game game) {
        player = new Hero(this);
        player.setPosition(startPosition());
       Door door = new Door(this);
        door.setPosition(doorPosition());
        door.addCollisionListener(new DoorListener(game));
        enemy = new Enemy(this);
        enemy.setPosition(enemyStartPosition());
    }

   /** The initial position of the player. */
    public abstract Vec2 startPosition();
    
    /** The position of the exit door. */
    public abstract Vec2 doorPosition();
    
    /** Is this level complete? */
    public abstract boolean isCompleted();
    public abstract Vec2 enemyStartPosition();
    
   
    
    
    
}
